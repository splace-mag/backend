Hier klicken um Ihr Passwort zurückzusetzen: 

{{ url('password/reset/'.$token) }}
